# Manoir abandonné — version Netlify

Jeu d'exploration 3D construit avec React, TypeScript et Babylon.js.

## Fonctionnalités

- Rendu 3D Babylon.js avec matériaux PBR et modèle `public/manoir_abandonne.glb`.
- Environnement atmosphérique Gaussian Splatting généré procéduralement, plus chargement d'un fichier `.splat`, `.ply` ou `.spz` depuis l'interface.
- Éclairage nocturne, brouillard, ombres, post-traitement cinématique et sondes de réflexion.
- Exploration, caméra orbitale, interactions, objets à collecter et sauvegarde locale.
- Contrôles tactiles et niveaux de qualité adaptatifs.

> Le Gaussian Splatting procédural enrichit principalement l'environnement extérieur. Le modèle GLB et les meshes Babylon.js restent utilisés pour les éléments architecturaux et interactifs. Pour un décor Gaussian réellement photogrammétrique, il faut fournir un scan `.splat`, `.ply` ou `.spz` compatible.

## Lancer en local

Prérequis : Node.js 20 ou plus récent.

```bash
npm install
npm run dev
```

## Vérifier la version de production

```bash
npm run lint
npm run build
npm run preview
```

Le site compilé est créé dans `dist/`.

## Publier sur Netlify

Le fichier `netlify.toml` configure automatiquement :

- commande de build : `npm run build`
- dossier publié : `dist`
- Node.js : version 20
- cache long pour le modèle GLB et les assets compilés

Méthode recommandée : importer le dépôt GitHub dans Netlify, puis lancer le déploiement. Il est aussi possible de déposer le dossier `dist` dans Netlify Drop après avoir exécuté le build en local.

Le modèle est servi depuis `/manoir_abandonne.glb`. Ne pas le déplacer hors de `public/` sans modifier le chemin dans `src/scene/ManoirEngine.ts`.
